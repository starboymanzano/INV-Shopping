<div id="menubar">
			<ul id="ul-menu">
				<li><a href="index.php">Home</a></li>
				<li><a href="all_products.php">All Products</a></li>
				<?php 
					if (isset($_SESSION['customer_email'])) {
						echo "<li><a href='customer/my_account.php'>My Account</a></li>"; 
					} else {
						echo "<li><a href='checkout.php'>My Account</a></li>";
					}
				?>
				<li><a href="cart.php">Shopping Cart</a></li>
				
			</ul>

			<div id="menu-form">
				<form method="get" action="results.php" enctype="multipart/form-data" />
					<input type="text" name="user-query" placeholder="Products or Brands" />
					<input type="submit" name="Submit" value="Search" />
				</form>
			</div>
</div>