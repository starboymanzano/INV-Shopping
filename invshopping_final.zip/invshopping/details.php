<!DOCTYPE html>
<?php 
session_start();
require_once("functions/functions.php"); ?>
<html>
<head>
	<title>INV Online Shop</title>
	<link rel="stylesheet" type="text/css" href="styles/style.css" media="all" />
</head>
<body>

	<!--Main Container Starts Here-->
	<div id="main-wrapper">
		<!--Header starts-->
			<?php include_once("header.php"); ?>
		<!--Header ends-->

		<!--Navigation bar starts-->
			<?php include_once("menu.php"); ?>
		<!--Navigation bar ends-->

		<!--Content wrapper starts-->
		<!--Sidebar starts-->
			<?php include_once("sidebar.php"); ?>
		<!--Sidebar ends-->
			<div id="content-area">
			<!--Shopping cart starts-->
				<?php include_once("shoppingmenu.php") ?>
			<!--Shopping cart ends-->
				<div id="prod-box">
					<?php
						if (isset($_GET['prod_id'])) {
							$get_id = $_GET['prod_id'];
							
							$get_prod = "SELECT * FROM products WHERE product_id='$get_id'";

							$run_prod = mysqli_query($conn, $get_prod);

							while ($row_prod = mysqli_fetch_array($run_prod)) {
								$prod_id = $row_prod['product_id'];
								$prod_cat = $row_prod['product_cat'];
								$prod_title = $row_prod['product_title'];
								$prod_price = $row_prod['product_price'];
								$prod_image = $row_prod['product_image'];
								$prod_desc = $row_prod['product_desc'];
						
							echo "<div id='single-prod'>
									<h3 align='center'>$prod_title</h3>
									<img src='admin_area/product_images/$prod_image' width='400' height='300' />
									<p align='center''><b>Price: &#8369 $prod_price.00</b></p></br>
									<p align='left'>$prod_desc</p></br>
									<a href='index.php' style='float:left;'>Go Back</a>
									<a href='index.php?add_cart=$prod_id'><button style='float:right'>Add to Cart</button></a>
								</div>";
							}
						}
					?>
				</div>
			</div>
		</div>
		<!--Content wrapper ends-->

		<!--Footer starts-->
			<?php include_once("footer.php"); ?>
		<!--Footer ends-->
	</div>
	<!--Main Container ends here-->
</body>
</html>