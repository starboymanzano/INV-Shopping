<?php 
	$serverName = "localhost";
	$userName = "root";
	$passWord = "";
	$dbName = "ecommerce_inv";

	$conn = mysqli_connect($serverName, $userName, $passWord, $dbName);
	
	if (!$conn) {
		die("Failed to connect to MySQL: " . mysqli_error($conn));
	}
	
	//Get IP address to count the visitors
	function getIp() {
    $ip = $_SERVER['REMOTE_ADDR'];
 
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
        $ip = $_SERVER['HTTP_CLIENT_IP'];
    } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
    }
 
    return $ip;
}
 ?>