<br/>

<h2 style="text-align:center;">Do you really want to DEACTIVATE your Account?</h2>

<form action="" method="post">

	<br/>
	<input type="submit" name="yes" value="Yes, I want!" />
	<input type="submit" name="no" value="No, I was joking" />

</form>

<?php 

	$user = $_SESSION['customer_email'];

	if (isset($_POST['yes'])) {

		$deact_acc = "DELETE FROM customers WHERE customer_email='$user'";

		mysqli_query($conn, $deact_acc);

		echo "<script>alert('Your account has been deactivated successfully!')</script>";

		echo "<script>window.open('../index.php','_self')</script>";

		session_destroy();

		
	}

	if (isset($_POST['no'])) {

		echo "<script>alert('Thank you, do not joke again!')</script>";

		echo "<script>window.open('my_account.php','_self')</script>";	

	}



 ?>