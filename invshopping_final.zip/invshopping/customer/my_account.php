<!DOCTYPE html>
<?php
session_start();
if (!isset($_SESSION['customer_email'])) {
	header("Location: ../index.php");
}
require_once("functions/functions.php"); ?>
<html>
<head>
	<title>INV Online Shop</title>
	<link rel="stylesheet" type="text/css" href="styles/style.css" media="all" />
</head>
<body>

	<!--Main Container Starts Here-->
	<div id="main-wrapper">
		<!--Header starts-->
			<?php include_once("../header.php"); ?>
		<!--Header ends-->
		

		<!--Navigation bar starts-->
			<div id="menubar">
			<ul id="ul-menu">
				<li><a href="../index.php">Home</a></li>
				<li><a href="../all_products.php">All Products</a></li>
				<li><a href="my_account.php">My Account</a></li>
				<li><a href="../cart.php">Shopping Cart</a></li>
				
				
			</ul>

			
		</div>
		<!--Navigation bar ends-->
		<div id="shopping-cart">

			<span>

			<?php 
				if(isset($_SESSION['customer_email'])) {

					echo "<b>Welcome: </b>" . $_SESSION['customer_email'];

				} 
				/*
				if (!isset($_SESSION['customer_email'])) {

						echo "<a href='../checkout.php' style='color:red;'>Login</a>";
							
				} else {

						echo "<a href='../logout.php' style='color:orange;'>Logout</a>";
				}
				*/
				?>
			</span>

			
		</div>
		<!--Content wrapper starts-->
		<!--Sidebar starts-->
			<div id="content-wrapper">
			<div id="sidebar">
				<div id="sidebar-title">My Profile</div>

				<ul id="sidebar-cats">
					<?php 
						$user = $_SESSION['customer_email'];

						$get_img = "SELECT * FROM customers WHERE customer_email='$user'";

						$run_img = mysqli_query($conn, $get_img);

						$row_img = mysqli_fetch_array($run_img);

						$c_image = $row_img['customer_image'];

						$c_name = $row_img['customer_name'];

						echo "<p style='text-align:center;'><img src='customer_images/$c_image' width='140' height='160'/></p>";
					?>
					<li><a href="my_account.php?my_orders">My Orders</a></li>
					<li><a href="my_account.php?edit_account">Edit Account</a></li>
					<li><a href="my_account.php?change_pass">Change Password</a></li>
					<li><a href="my_account.php?deactivate_account">Deactivate Account</a></li>
					<li><a href="../logout.php">Logout</a></li>
				</ul>
			</div>
		<!--Sidebar ends-->
			<div id="content-area">
			
				<?php cart(); ?>
				<div id="prod-box">
					

					<?php 

						if(!isset($_GET['my_orders'])) {
							if(!isset($_GET['edit_account'])) {
								if(!isset($_GET['change_pass'])) {
									if(!isset($_GET['deactivate_account'])) {
						echo "<h2>Welcome: <b><?php echo $c_name; ?></b></h2><br/><br/>";
						echo "<p>You can see your orders progress by clicking this <a href='my_account.php?my_orders'>link</a></p>";
					}
					}
					}	
					}
					?>

					<?php 
						if(isset($_GET['edit_account'])) {
							include_once('edit_account.php');
						}

						if(isset($_GET['change_pass'])) {
							include_once('change_pass.php');
						}

						if(isset($_GET['deactivate_account'])) {
							include_once('deactivate_account.php');
						}
					 ?>
				</div>
			</div>
		</div>
		<!--Content wrapper ends-->

		<!--Footer starts-->
			<?php include_once("../footer.php"); ?>
		<!--Footer ends-->
	</div>
	<!--Main Container ends here-->
</body>
</html>