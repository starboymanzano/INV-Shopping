<!DOCTYPE html>
<?php require_once("functions/functions.php"); ?>
<html>
<head>
	<title>INV Online Shop</title>
	<link rel="stylesheet" type="text/css" href="styles/style.css" media="all" />
</head>
<body>

	<!--Main Container Starts Here-->
	<div id="main-wrapper">
		<!--Header starts-->
			<?php include_once("header.php"); ?>
		<!--Header ends-->

		<!--Navigation bar starts-->
			<?php include_once("menu.php"); ?>
		<!--Navigation bar ends-->

		<!--Content wrapper starts-->
		<!--Sidebar starts-->
			<?php include_once("sidebar.php"); ?>
		<!--Sidebar ends-->
			<div id="content-area">
			<!--Shopping cart starts-->
				<?php include_once("shoppingmenu.php") ?>
			<!--Shopping cart ends-->
				<div id="prod-box">
					<?php
						if (isset($_GET['Submit'])) {
							
							
							$submit_query = $_GET['user-query'];
					
							$get_prod = "SELECT * FROM products WHERE product_keywords LIKE '%$submit_query%'";

							$run_prod = mysqli_query($conn, $get_prod);
							
							$search_count = mysqli_num_rows($run_prod);
							
							if ($search_count == 0) {
								echo "<h2 style='padding:20px'>No results found!</h2>";
							}
							
							while ($row_prod = mysqli_fetch_array($run_prod)) {
								$prod_id = $row_prod['product_id'];
								$prod_cat = $row_prod['product_cat'];
								$prod_brand = $row_prod['product_brand'];
								$prod_title = $row_prod['product_title'];
								$prod_price = $row_prod['product_price'];
								$prod_image = $row_prod['product_image'];

							echo "<div id='single-prod'>
									<h3 align='center'>$prod_title</h3>
									<img src='admin_area/product_images/$prod_image' width='180' height='180' />
									<p align='center'><b>&#8369 $prod_price.00</b></p>
									<a href='details.php?prod_id=$prod_id' style='float:left;'>Details</a>
									<a href='index.php?prod_id=$prod_id'><button style='float:right'>Add to Cart</button></a>
								</div>";
							}
						}
					?>
				</div>
			</div>
		</div>
		<!--Content wrapper ends-->

		<!--Footer starts-->
			<?php include_once("footer.php"); ?>
		<!--Footer ends-->
	</div>
	<!--Main Container ends here-->
</body>
</html>