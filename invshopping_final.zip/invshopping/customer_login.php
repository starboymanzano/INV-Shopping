<head>
	<link rel="stylesheet" type="text/css" href="styles/style.css">
</head>
<div id ="loginPage">
<div id="loginForm">
	<form method="post" action="" id="legendForm">
		<legend>Login or Register to buy</legend>
   		 	<input type="email" name="email" placeholder="Enter E-mail" required/>
    		<input type="password" name="pass" placeholder="Enter Password" required/>
    		<a class="forgot-pass" href="checkout.php?forgot_pass">Forgot Password?</a>
    	<input type="submit" name="login" value="Login!" />
    	<a class="new-user" href="customer_register.php">New? Register here</a>
	</form>

	<?php 
		if (isset($_POST['login'])) {

			$c_email = $_POST['email'];
			$c_pass = $_POST['pass'];

			$sel_c = "SELECT * FROM customers where customer_email='$c_email' AND customer_pass='$c_pass'";

			$run_c = mysqli_query($conn, $sel_c);

			$check_customer = mysqli_num_rows($run_c);

			if ($check_customer == 0) {

				echo "<script>alert('Username or Password is incorrect. Try Again!')</script>";
				exit();
			} 
				$ip = getIp();

				$sel_cart = "SELECT * FROM cart WHERE p_ipadd='$ip'";

				$run_cart = mysqli_query($conn, $sel_cart);

				$check_cart = mysqli_num_rows($run_cart);

				if ($check_customer > 0 AND $check_cart == 0) {

					$_SESSION['customer_email'] = $c_email;

					echo "<script>alert('You have logged in, Thanks!')</script>";

					echo "<script>window.open('customer/my_account.php','_self')</script>";

				} else 

					$_SESSION['customer_email'] = $c_email;

					echo "<script>alert('You have logged in, Thanks!')</script>";

					echo "<script>window.open('checkout.php','_self')</script>";


				}




	 ?>
</div>
</div>