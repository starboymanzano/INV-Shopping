<?php
require_once("includes/db.php");


/*For testing only (Lessons in PHP Web Programming 3)
if (!$conn) {
	die("Connection error" . mysqli_error($conn));
}
echo "Connection successful";
*/


//Getting the categories in Sidebar
function getCats() {
	global $conn;
	$get_cats = "SELECT * FROM categories";
	$run_cats = mysqli_query($conn, $get_cats);

	while ($row_cats = mysqli_fetch_array($run_cats)) {
		$cat_id = $row_cats['cat_id'];
		$cat_title = $row_cats['cat_title'];
		echo "<li><a href='index.php?cat=$cat_id'>$cat_title</a></li>";
	}
}

//Getting the brands in Sidebar
function getBrands() {
	global $conn;
	$get_brands = "SELECT * FROM brands";
	$run_brands = mysqli_query($conn, $get_brands);

	while ($row_brands = mysqli_fetch_array($run_brands)) {
		$brand_id = $row_brands['brand_id'];
		$brand_title = $row_brands['brand_title'];
		echo "<li><a href='index.php?brand=$brand_id'>$brand_title</a></li>";
	}
}

//Getting products to show in product box content
function getProds() {
	if (!isset($_GET['cat'])) {
		if (!isset($_GET['brand'])) {
	global $conn;

	$get_prod = "SELECT * FROM products order by  product_id DESC LIMIT 0,9";

	$run_prod = mysqli_query($conn, $get_prod);

	while ($row_prod = mysqli_fetch_array($run_prod)) {
		$prod_id = $row_prod['product_id'];
		$prod_cat = $row_prod['product_cat'];
		$prod_brand = $row_prod['product_brand'];
		$prod_title = $row_prod['product_title'];
		$prod_price = $row_prod['product_price'];
		$prod_image = $row_prod['product_image'];

		echo "<div id='single-prod'>
				<h3 align='center'>$prod_title</h3>
				<img src='admin_area/product_images/$prod_image' width='180' height='180' />
				<p align='center'><b>Price: &#8369; $prod_price.00</b></p>
				<a href='details.php?prod_id=$prod_id' style='float:left;'>Details</a>
				<a href='index.php?add_cart=$prod_id'><button style='float:right'>Add to Cart</button></a>
			</div>";
	}
	
		}
	}
}

//Getting Category Products (FILTER)
function getCatProds() {
	if (isset($_GET['cat'])) {
		
			$cat_id = $_GET['cat'];
		
	global $conn;

	$get_cat_prod = "SELECT * FROM products WHERE product_cat='$cat_id'";

	$run_cat_prod = mysqli_query($conn, $get_cat_prod);
	
	$count_cat = mysqli_num_rows($run_cat_prod);
	
	if ($count_cat == 0) {
		echo "<h2 style='padding:20px'>There is no product found in this category!</h2>";
		die();
	}  
		
		while ($row_cat_prod = mysqli_fetch_array($run_cat_prod)) {
			$prod_id = $row_cat_prod['product_id'];
			$prod_cat = $row_cat_prod['product_cat'];
			$prod_brand = $row_cat_prod['product_brand'];
			$prod_title = $row_cat_prod['product_title'];
			$prod_price = $row_cat_prod['product_price'];
			$prod_image = $row_cat_prod['product_image'];

			echo "<div id='single-prod'>
					<h3 align='center'>$prod_title</h3>
					<img src='admin_area/product_images/$prod_image' width='180' height='180' />
					<p align='center'><b>&#8369 $prod_price.00</b></p>
					<a href='details.php?prod_id=$prod_id' style='float:left;'>Details</a>
					<a href='index.php?add_cart=$prod_id'><button style='float:right'>Add to Cart</button></a>
				</div>";
		}
	}
		
	}
	
	//Getting Brand Products (FILTER)
	function getBrandProds() {
	if (isset($_GET['brand'])) {
		
			$brand_id = $_GET['brand'];
		
	global $conn;

	$get_brand_prod = "SELECT * FROM products WHERE product_brand='$brand_id'";

	$run_brand_prod = mysqli_query($conn, $get_brand_prod);
	
	$count_brand = mysqli_num_rows($run_brand_prod);
	
	if ($count_brand == 0) {
		echo "<h2 style='padding:20px'>There is no products found in this brand!</h2>";
		die();
	}  
		
		while ($row_brand_prod = mysqli_fetch_array($run_brand_prod)) {
			$prod_brand = $row_brand_prod['product_id'];
			$prod_cat = $row_brand_prod['product_cat'];
			$prod_brand = $row_brand_prod['product_brand'];
			$prod_title = $row_brand_prod['product_title'];
			$prod_price = $row_brand_prod['product_price'];
			$prod_image = $row_brand_prod['product_image'];

			echo "<div id='single-prod'>
					<h3 align='center'>$prod_title</h3>
					<img src='admin_area/product_images/$prod_image' width='180' height='180' />
					<p align='center'><b>&#8369 $prod_price.00</b></p>
					<a href='details.php?brand_id=$brand_id' style='float:left;'>Details</a>
					<a href='index.php?add_cart=$brand_id'><button style='float:right'>Add to Cart</button></a>
				</div>";
		}
	}
		
	}
	
	//Creating the shopping cart
	function cart() {
		if (isset($_GET['add_cart'])) {
			global $conn;
			$ip = getIp();
			$prod_id = $_GET['add_cart'];
			$check_prod = "SELECT * FROM cart WHERE p_ipadd='$ip' AND  p_id='$prod_id'";
			$run_check = mysqli_query($conn, $check_prod);
			
			if (mysqli_num_rows($run_check) > 0) {
				
			} else {
				$insert_prod = "INSERT INTO cart (p_id, p_ipadd) VALUES ('$prod_id','$ip')";
				$run_prod = mysqli_query($conn, $insert_prod);
				echo  "<script>window.open('index.php','_self')</script>";
				
			}
		}
	}
	
	//Creating the shopping cart
	function all_products_cart() {
		if (isset($_GET['add_cart'])) {
			global $conn;
			$ip = getIp();
			$prod_id = $_GET['add_cart'];
			$check_prod = "SELECT * FROM cart WHERE p_ipadd='$ip' AND  p_id='$prod_id'";
			$run_check = mysqli_query($conn, $check_prod);
			
			if (mysqli_num_rows($run_check) > 0) {
				
			} else {
				$insert_prod = "INSERT INTO cart (p_id, p_ipadd) VALUES ('$prod_id','$ip')";
				$run_prod = mysqli_query($conn, $insert_prod);
				echo  "<script>window.open('all_products.php','_self')</script>";
				
			}
		}
	}

	//Getting total items from the index.php
	function total_items() {
		if (isset($_GET['add_cart'])) {
			global $conn;
			$ip = getIp();
			$get_items = "SELECT * FROM cart WHERE p_ipadd='$ip'";
			$run_items = mysqli_query($conn, $get_items);
			$count_items = mysqli_num_rows($run_items);
			echo $count_items;
		} else {
			global $conn;
			$ip = getIp();
			$get_items = "SELECT * FROM cart WHERE p_ipadd='$ip'";
			$run_items = mysqli_query($conn, $get_items);
			$count_items = mysqli_num_rows($run_items);
			echo $count_items;
		}
	}
	
	//Getting total items from all_products.php
	function search_all_products() {
		global $conn;
		$get_prod = "SELECT * FROM products";
		$run_prod = mysqli_query($conn, $get_prod);	
		$count_prod = mysqli_num_rows($run_prod);
						
		if ($count_prod == 0) {
			echo "<h2 style='padding:20px'>There is no product or brand!</h2>";
			die();
		}
		
		while ($row_prod = mysqli_fetch_array($run_prod)) {
		$prod_id = $row_prod['product_id'];
		$prod_cat = $row_prod['product_cat'];
		$prod_brand = $row_prod['product_brand'];
		$prod_title = $row_prod['product_title'];
		$prod_price = $row_prod['product_price'];
		$prod_image = $row_prod['product_image'];

		echo "<div id='single-prod'>
		<h3 align='center'>$prod_title</h3>
		<img src='admin_area/product_images/$prod_image' width='180' height='180' />
		<p align='center'><b>Price: &#8369 $prod_price.00</b></p>
		<a href='details.php?prod_id=$prod_id' style='float:left;'>Details</a>
		<a href='all_products.php?add_cart=$prod_id'><button style='float:right'>Add to Cart</button></a>
		</div>";
			}
		}
		
		//Getting total price
		function total_price() {
			$total = 0;
			global $conn;
			$ip = getIp();
			$sel_price = "SELECT  * FROM cart WHERE p_ipadd='$ip'";
			$run_price = mysqli_query($conn, $sel_price);
			
			while ($p_price = mysqli_fetch_array($run_price)) {
				$prod_id = $p_price['p_id'];
				$prod_price = "SELECT * FROM products WHERE product_id='$prod_id'";
				$run_prod_price = mysqli_query($conn, $prod_price);
				
			while ($pp_price = mysqli_fetch_array($run_prod_price)) {
				$product_price  = array($pp_price['product_price']);
				$values = array_sum($product_price);
				$total += $values;
				
				}
			}
			
			echo "&#8369;" . "$total";
		}


?>