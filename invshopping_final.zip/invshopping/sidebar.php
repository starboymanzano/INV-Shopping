<div id="content-wrapper">
			<div id="sidebar">
				<div id="sidebar-title">Categories</div>

				<ul id="sidebar-cats">
					<?php getCats(); ?>
				</ul>

				<div id="sidebar-title">Brands</div>

				<ul id="sidebar-cats">
					<?php getBrands(); ?>
				</ul>
</div>