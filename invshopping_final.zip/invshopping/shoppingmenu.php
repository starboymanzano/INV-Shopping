<div id="shopping-cart">
	<span>

	<?php 
		if(isset($_SESSION['customer_email'])) {

			echo "<b>Welcome: </b>" . $_SESSION['customer_email'] . " | Your ";

		} else {

			echo "<b>Welcome Guest | </b>";
		}
	 ?>

	Total Items: <?php total_items(); ?> | Total Price: <?php total_price(); ?> | <a href="cart.php" style="color:yellow;">Go to Cart</a> | <?php 
		if (!isset($_SESSION['customer_email'])) {

				echo "<a href='checkout.php' style='color:red;'>Login</a>";
					
		} else {

				echo "<a href='logout.php' style='color:orange;'>Logout</a>";
		}

	?></span>

	
</div>

