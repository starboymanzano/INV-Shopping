<!DOCTYPE html>
<?php 
session_start();
require_once("functions/functions.php"); ?>
<html>
<head>
	<title>INV Online Shop</title>
	<link rel="stylesheet" type="text/css" href="styles/style.css" media="all" />
</head>
<body>

	<!--Main Container Starts Here-->
	<div id="main-wrapper">
		<!--Header starts-->
			<?php include_once("header.php"); ?>
		<!--Header ends-->

		<!--Navigation bar starts-->
			<?php include_once("menu.php"); ?>
		<!--Navigation bar ends-->

		<!--Content wrapper starts-->
		<!--Sidebar starts-->
			<?php include_once("sidebar.php"); ?>
		<!--Sidebar ends-->
			<div id="content-area">
			<!--Shopping cart starts-->
				<?php include_once("shoppingmenu.php") ?>
			<!--Shopping cart ends-->
				<?php cart(); ?>
				<div>
					<div>
						<form action="customer_register.php" method="post" enctype="multipart/form-data">
							
						<table align="left" width="700">
							<tr>
								<td colspan="8"><h2>Create an Account</h2></td>
							</tr>

							<tr>
								<td align="right">Customer Name: </td>
								<td>	<input type="text" name="c_name" required/></td>
							</tr>

							<tr>
								<td align="right">Customer Email: </td>
								<td><input type="email" name="c_email" required/></td>
							</tr>

							<tr>
								<td align="right">Customer Password:</td>
								<td><input type="password" name="c_pass" required/></td>
							</tr>

							<tr>
								<td align="right">Customer Country: </td>
								<td><select name="c_country" required>
									<option>Select a Country</option>
									<option>Philippines</option>
									<option>United States</option>
									<option>Singapore</option>
									<option>Saudi Arabia</option>
									<option>Japan</option>
									<option>Australia</option>
									<option>Switzerland</option>
									<option>New Zealand</option>
									<option>United Arab Emirates</option>
									<option>Taiwan</option>
								</select></td>
							</tr>

							<tr>
								<td align="right">Customer Address: </td>
								<td><input type="text" name="c_add" required/></td>
							</tr>

							<tr>
								<td align="right">Customer City: </td>
								<td><input type="text" name="c_city" required/></td>
							</tr>

							<tr>
								<td align="right">Customer Contact: </td>
								<td><input type="contact" name="c_contact" required/></td>
							</tr>

							<tr>
								<td align="right">Customer Image: </td>
								<td><input type="file" name="c_image" required/></td>
							</tr>

							<tr>
								<td align="right"><input type="submit" name="register" value="Create Account" /></td>
							</tr>
						</table>
						</form>
					</div>	
				</div>
				</div>
			</div>
		</div>
		<!--Content wrapper ends-->

		<!--Footer starts-->
			<?php include_once("footer.php"); ?>
		<!--Footer ends-->
	</div>
	<!--Main Container ends here-->
</body>
</html>

<?php 
	if (isset($_POST['register'])) {
		$ip = getIp();
		$c_name = $_POST['c_name'];
		$c_email = $_POST['c_email'];
		$c_pass = $_POST['c_pass'];
		$c_country = $_POST['c_country'];
		$c_add = $_POST['c_add'];
		$c_city = $_POST['c_city'];
		$c_contact = $_POST['c_contact'];
		$c_image = $_FILES['c_image']['name'];
		$c_image_tmp = $_FILES['c_image']['tmp_name'];

		move_uploaded_file($c_image_tmp, "customer/customer_images/$c_image");

		$insert_c = "INSERT INTO customers (customer_ip, customer_name, customer_email, customer_pass, customer_country, customer_address, customer_city, customer_contact, customer_image) VALUES ('$ip','$c_name','$c_email','$c_pass','$c_country','$c_add','$c_city','$c_contact','$c_image')";

		$run_c = mysqli_query($conn, $insert_c);

		$sel_cart = "SELECT * FROM cart WHERE p_ipadd='$ip'";

		$run_cart = mysqli_query($conn, $sel_cart);

		$check_cart = mysqli_num_rows($run_cart);

		if ($check_cart == 0 ) {

		$_SESSION['customer_email'] = $c_email;

			echo "<script>alert('Account has been created successful. Thanks!')</script>";

			echo "<script>window.open('customer/my_account.php','_self')</script>";
		} else {

			$_SESSION['customer_email'] = $c_email;

			echo "<script>alert('Account has been created successful. Thanks!')</script>";

			echo "<script>window.open('checkout.php','_self')</script>";
		}
	}
 ?> 