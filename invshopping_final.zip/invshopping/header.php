<div id="header-wrapper">
	<a href="index.php"><img id="shop-logo" src="images/shop-logo.png"/></a>
	<a href="index.php"><img id="ad-banner" src="images/banner.gif"/></a>
</div>