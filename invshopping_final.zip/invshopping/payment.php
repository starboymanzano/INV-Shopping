<div>
	<h2 align="center">Pay now with Paypal</h2>
	<p style="text-align:center;"><img src="images/paypal.png" width="200" height="100" /></p>
</div>