<?php 

  if (!isset($_SESSION['user'])) {

    header("Location: login.php");

  }
    ?>

<table width="795" align="center" bgcolor="pink">

	<tr align="center">
		<td colspan="8"><h2>View All Categories</h2></td>
	</tr>

	<tr align="center" bgcolor="orange">
		<th>Category ID </th>
		<th>Category Title</th>
		<th>Edit</th>
		<th>Delete</th>
	</tr>
	

	<?php 

		$get_cat = "SELECT * FROM categories";

		$run_cat = mysqli_query($conn, $get_cat);

		

		while ($row_cat = mysqli_fetch_array($run_cat)) {

			$cat_id    = $row_cat['cat_id'];
			$cat_title = $row_cat['cat_title'];
			
	 	
	?>

	<tr align="center">
		<td><?php echo $cat_id; ?></td>
		<td><?php echo $cat_title; ?></td>
		<td><a href="index.php?edit_cat=<?php echo $cat_id; ?>">Edit</a></td>
		<td><a href="delete_cat.php?delete_cat=<?php echo $cat_id ?>">Delete</a></td>
	</tr>

	<?php } ?>

	<?php 
		

			if (isset($_GET['delete_cat'])) {
				include_once("delete_cat.php");
			}
		?>


	
</table>