<!DOCTYPE html>

<?php 
  session_start();

   include("includes/db.php");

  if (isset($_SESSION['user'])) {

    header("Location: index.php");

  }
    ?>


<html>
<head>
  <title>Admin Login</title>
  <link rel="stylesheet" type="text/css" href="styles/login_style.css" media="all">
</head>
<body>
  <div class="container">
  <div id="login-form">
    <h3>Admin Login</h3>
    <fieldset>
      <form action="login.php" method="post">

        <input type="text" name="user" required placeholder="Admin User" autofocus> 
        <input type="password" name="pass" required placeholder="Admin Pass"> 
        <input type="submit" name="login" value="Login">
        

      </form>
    </fieldset>
  </div> 
</div>
</body>
</html>

<?php 


    if(isset($_POST['login'])) {
      $user = $_POST['user'];
      $pass = $_POST['pass'];


      $select_user = "SELECT * FROM admins WHERE admin_user='$user' AND admin_pass='$pass'";
      
      $run_user = mysqli_query($conn, $select_user);

      $check_user = mysqli_num_rows($run_user);

      if ($check_user == 0) {

        echo "<script>alert('Admin user or password is wrong, try again!')</script>";

      } else {

        $_SESSION['user'] = $user;

        echo "<script>window.open('index.php', '_self')</script>";

      }
      
    }
 ?>

