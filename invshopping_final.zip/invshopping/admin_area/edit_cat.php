<?php 
	if (isset($_GET['edit_cat'])) {

 		$get_cat_id = $_GET['edit_cat'];

 		$get_cat = "SELECT * from categories WHERE cat_id='$get_cat_id'";

 		$run_cat = mysqli_query($conn, $get_cat);

 		$row_cat = mysqli_fetch_array($run_cat);

 		$cat_title = $row_cat['cat_title'];

 	}
 ?>


<form action="" method="post" style="padding: 40px;"> 
	
<b>Update Category: </b>
<input type="text" name="new_cat" value="<?php echo $cat_title ?>" required />
<input type="submit" name="update_cat" value="Update Category" />

</form>

<?php 

	if (isset($_POST['update_cat'])) {

	$update_id = $get_cat_id;

	$new_cat = $_POST['new_cat'];

	$update_cat = "UPDATE categories SET cat_title='$new_cat' WHERE cat_id='$update_id'";

	$run_cat = mysqli_query($conn, $update_cat);

	if ($run_cat) {

		echo "<script>alert('Category has been updated')</script>";
		echo "<script>window.open('index.php?view_cats','_self')</script>";

	}

}

 ?>
