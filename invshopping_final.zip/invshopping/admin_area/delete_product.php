<?php 
	require_once("includes/db.php");
 ?>

 <?php 
 	if (isset($_GET['delete_prod'])) {

 		$delete_id = $_GET['delete_prod'];

 		$delete_prod = "DELETE from products WHERE product_id='$delete_id'";

 		$run_delete = mysqli_query($conn, $delete_prod);

 		if ($run_delete) {

		 		echo "<script>alert('Product has been deleted')</script>";

		 		echo "<script>window.open('index.php?view_products','_self')</script>";
 	
	 	}
	 	
 	}
  ?>