<?php 

  if (!isset($_SESSION['user'])) {

    header("Location: login.php");

  }
    ?>

<table width="795" align="center" bgcolor="pink">

	<tr align="center">
		<td colspan="8"><h2>View All Products Here</h2></td>
	</tr>

	<tr align="center" bgcolor="orange">
		<th>No. </th>
		<th>Title</th>
		<th>Image</th>
		<th>Price</th>
		<th>Edit</th>
		<th>Delete</th>
	</tr>
	

	<?php 

		$get_pro = "SELECT * FROM products";

		$run_pro = mysqli_query($conn, $get_pro);

		$i = 0;

		while ($row_pro = mysqli_fetch_array($run_pro)) {

			$prod_id    = $row_pro['product_id'];
			$prod_title = $row_pro['product_title'];
			$prod_image = $row_pro['product_image'];
			$prod_price = $row_pro['product_price'];
			$i++;
	 	
	?>

	<tr align="center">
		<td><?php echo $i; ?></td>
		<td><?php echo $prod_title; ?></td>
		<td><?php echo "<img src='product_images/$prod_image' height='40' width='40'/>"; ?></td>
		<td><?php echo "&#8369; " . $prod_price; ?></td>
		<td><a href="index.php?edit_prod=<?php echo $prod_id; ?>">Edit</a></td>
		<td><a href="delete_product.php?delete_prod=<?php echo $prod_id ?>">Delete</a></td>
	</tr>

	<?php } ?>

	<?php 
		

			if (isset($_GET['delete_prod'])) {
				include_once("delete_product.php");
			}
		?>


	
</table>