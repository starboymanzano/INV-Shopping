<?php 
	require_once("includes/db.php");
 ?>

 <?php 
 	if (isset($_GET['delete_c'])) {

 		$delete_id = $_GET['delete_c'];

 		$delete_c = "DELETE from customers WHERE customer_id='$delete_id'";

 		$run_delete = mysqli_query($conn, $delete_c);

 		if ($run_delete) {

		 		echo "<script>alert('User/Customer has been deleted')</script>";

		 		echo "<script>window.open('index.php?view_customers','_self')</script>";
 	
	 	}
	 	
 	}
  ?>