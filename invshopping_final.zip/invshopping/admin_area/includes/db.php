<?php 
	$serverName = "localhost";
	$userName = "root";
	$passWord = "";
	$dbName = "ecommerce_inv";

	$conn = mysqli_connect($serverName, $userName, $passWord, $dbName);
 ?>