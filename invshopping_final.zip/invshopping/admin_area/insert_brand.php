<form action="" method="post" style="padding: 40px;"> 
	
<b>Insert New Brand: </b>
<input type="text" name="new_brand" required />
<input type="submit" name="add_brand" value="Add Brand" />

</form>

<?php 
	if (isset($_POST['add_brand'])) {

	$new_brand = $_POST['new_brand'];

	$update_brand = "INSERT INTO brands (brand_title) VALUES ('$new_brand')";

	$run_brand = mysqli_query($conn, $update_brand);

	if ($run_brand) {

		echo "<script>alert('New Brand has been added')</script>";
		echo "<script>window.open('index.php?view_brands','_self')</script>";

	}

}

 ?>
