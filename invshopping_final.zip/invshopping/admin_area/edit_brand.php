<?php 
	if (isset($_GET['edit_brand'])) {

 		$get_brand_id = $_GET['edit_brand'];

 		$get_brand = "SELECT * from brands WHERE brand_id='$get_brand_id'";

 		$run_brand = mysqli_query($conn, $get_brand);

 		$row_brand = mysqli_fetch_array($run_brand);

 		$brand_title = $row_brand['brand_title'];

 	}
 ?>


<form action="" method="post" style="padding: 40px;"> 
	
<b>Update Brand: </b>
<input type="text" name="new_brand" value="<?php echo $brand_title ?>" required />
<input type="submit" name="update_brand" value="Update Brand" />

</form>

<?php 

	if (isset($_POST['update_brand'])) {

	$update_brand = $get_brand_id;

	$new_brand = $_POST['new_brand'];

	$update_brand = "UPDATE brands SET brand_title='$new_brand' WHERE brand_id='$update_brand'";

	$run_brand = mysqli_query($conn, $update_brand);

	if ($run_brand) {

		echo "<script>alert('Brand has been updated')</script>";
		echo "<script>window.open('index.php?view_brands','_self')</script>";

	}

}

 ?>
