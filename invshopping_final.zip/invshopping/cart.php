<!DOCTYPE html>
<?php 
	session_start();
	require_once("functions/functions.php"); 
?>
<html>
<head>
	<title>INV Online Shop</title>
	<link rel="stylesheet" type="text/css" href="styles/style.css" media="all" />
</head>
<body>

	<!--Main Container Starts Here-->
	<div id="main-wrapper">
		<!--Header starts-->
			<?php include_once("header.php"); ?>
		<!--Header ends-->

		<!--Navigation bar starts-->
			<?php include_once("menu.php"); ?>
		<!--Navigation bar ends-->

		<!--Content wrapper starts-->
		<!--Sidebar starts-->
			<?php include_once("sidebar.php"); ?>
		<!--Sidebar ends-->
			<div id="content-area">
			<!--Shopping cart starts-->
				<div id="shopping-cart">
						<span>

						<?php 
							if(isset($_SESSION['customer_email'])) {

								echo "<b>Welcome: </b>" . $_SESSION['customer_email'] . " | Your ";

							} else {

								echo "<b>Welcome Guest</b>";
							}
						 ?>

						Total Items: <?php total_items(); ?> | Total Price: <?php total_price(); ?> | <a href="index.php" style="color:yellow">Back to Shop</a> | <?php 
							if (!isset($_SESSION['customer_email'])) {

									echo "<a href='checkout.php' style='color:red;'>Login</a>";
										
							} else {

									echo "<a href='logout.php' style='color:orange;'>Logout</a>";
							}

						?></span>

						
				</div>
			<!--Shopping cart ends-->
				<?php cart(); ?>
				<div id="prod-box">
					<form action="" method="post" enctype="multipart/form-data">
						<table align="center" width="700" bgcolor="skyblue">
							<tr align="center">
								<th>Remove</th>
								<th>Product(s)</th>
								<th>Quantity</th>
								<th>Total Price</th>
								
								<?php 
									$single_price = "";
									$total = 0;
									global $conn;
									$ip = getIp();
									$sel_price = "SELECT  * FROM cart WHERE p_ipadd='$ip'";
									$run_price = mysqli_query($conn, $sel_price);
									
									while ($p_price = mysqli_fetch_array($run_price)) {
										$prod_id = $p_price['p_id'];
										$prod_price = "SELECT * FROM products WHERE product_id='$prod_id'";
										$run_prod_price = mysqli_query($conn, $prod_price);
										
									while ($pp_price = mysqli_fetch_array($run_prod_price)) {
										$product_price  = array($pp_price['product_price']);
										$product_title = $pp_price['product_title'];
										$product_image = $pp_price['product_image'];
										$single_price = $pp_price['product_price'];
										$values = array_sum($product_price);
										$total += $values;
								?>
									<tr align="center">
										<td><input type="checkbox" name="remove[]" value="<?php echo $prod_id; ?>"/></td>
										<td><?php echo $product_title; ?><br>
										<img src="admin_area/product_images/<?php echo $product_image; ?>" width="60" height="60"/>
										<td><input type="number" min="1" name="qty" value="<?php echo $_SESSION['qty']; ?>"/></td>
										<?php 
										if (isset($_POST['update_cart'])) {
											$qty = $_POST['qty'];
											

											$update_qty = "UPDATE cart SET qty='$qty'";
											
											$run_qty = mysqli_query($conn, $update_qty);
											
											$_SESSION['qty'] = $qty;
											$session_qty = $_SESSION['qty'];
											$total *= $session_qty;	

											

										}
									}
										
										?>
										<td><?php echo $single_price; ?></td>
									</tr>
								<?php
										} 
									
								?>
								
									<tr align="right">
											<td colspan="4"><b>Sub Total:</b></td>
											<td><?php 

								
											echo '&#8369; ' . $total ; ?></td>
									 
									</tr>
									
									<tr>
										<td colspan="2"><input type="submit" name="update_cart" value="Update Cart" /></td>
										<td><input type="submit" name="continue" value="Continue Shopping" /></td>
										<td><a href="checkout.php">Checkout</a></td>
										
									</tr>
						</table>
					</form>
						<?php 
						function updatecart() {
						
						global $conn;
						$ip = getIp();
						if (isset($_POST['update_cart'])) {
							foreach($_POST['remove'] as $remove_id) {
							$delete_product = "DELETE FROM cart WHERE p_id='$remove_id' AND p_ipadd='$ip'";
							$run_delete = mysqli_query($conn, $delete_product);
												
							if ($run_delete) {
								echo "<script>window.open('cart.php','_self')</script>";
								}
							}
						}
						
						if (isset($_POST['continue'])) {
							echo "<script>window.open('index.php','_self')</script>";
						}
						
						
						}
						
						echo @$up_cart = updatecart();
						?>
				</div>
			</div>
		</div>
		<!--Content wrapper ends-->

		<!--Footer starts-->
			<?php include_once("footer.php"); ?>
		<!--Footer ends-->
	</div>
	<!--Main Container ends here-->
</body>
</html>