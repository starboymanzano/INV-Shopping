<!DOCTYPE html>
<?php 
session_start();
require_once("functions/functions.php"); ?>
<html>
<head>
	<title>INV Online Shop</title>
	<link rel="stylesheet" type="text/css" href="styles/style.css" media="all" />
</head>
<body>

	<!--Main Container Starts Here-->
	<div id="main-wrapper">
		<!--Header starts-->
			<?php include_once("header.php"); ?>
		<!--Header ends-->

		<!--Navigation bar starts-->
			<?php include_once("menu.php"); ?>
		<!--Navigation bar ends-->

		<!--Content wrapper starts-->
		<!--Sidebar starts-->
			<?php include_once("sidebar.php"); ?>
		<!--Sidebar ends-->
			<div id="content-area">
			<!--Shopping cart starts-->
				<?php include_once("shoppingmenu.php") ?>
			<!--Shopping cart ends-->
				<?php cart(); ?>
				<div id="prod-box">
					<?php 
						if (!isset($_SESSION['customer_email'])) {
							include("customer_login.php");
						} else {
							include("payment.php");
						}
					?>
				</div>
			</div>
		</div>
		<!--Content wrapper ends-->

		<!--Footer starts-->
			<?php include_once("footer.php"); ?>
		<!--Footer ends-->
	</div>
	<!--Main Container ends here-->
</body>
</html>