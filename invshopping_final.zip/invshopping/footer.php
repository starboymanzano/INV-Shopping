<div id="footer">
	<div class="center">
	  <div class="box" id="facebook">&#62220;</div>
	  <div class="box" id="twitter">&#62217;</div>
	  <div class="box" id="google">&#62223;</div>
	  <div class="box" id="linkedin">&#62232;</div>
	</div>
</div>